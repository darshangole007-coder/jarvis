from flask import Flask, render_template, request, redirect, session
from flask_socketio import SocketIO, emit, join_room
import uuid, time, qrcode

app = Flask(__name__)
app.secret_key = "boss-secret"
socketio = SocketIO(app, cors_allowed_origins="*")

CONTROLLER_PASSWORD = "boss123"
rooms = {}

def new_room(video_id):
    return {
        "video_id": video_id,
        "playing": False,
        "time": 0,
        "last_update": time.time(),
        "viewers": 0
    }

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if request.form["password"] == CONTROLLER_PASSWORD:
            room = str(uuid.uuid4())[:6]
            rooms[room] = new_room(request.form["video_id"])
            session["room"] = room
            session["controller"] = True

            qr = qrcode.make(request.host_url + "watch/" + room)
            qr.save(f"static/{room}.png")

            return redirect("/controller")
    return render_template("login.html")

@app.route("/controller")
def controller():
    if not session.get("controller"):
        return redirect("/")
    return render_template("controller.html", room=session["room"])

@app.route("/watch/<room>")
def viewer(room):
    if room not in rooms:
        return "Room not found", 404
    return render_template("viewer.html", room=room, data=rooms[room])

@socketio.on("join")
def join(data):
    room = data.get("room")

    if not room or room not in rooms:
        print(f"[WARN] Join attempt for invalid room: {room}")
        return

    join_room(room)
    rooms[room]["viewers"] += 1

    emit("sync", rooms[room], room=room)
    emit("count", rooms[room]["viewers"], room=room)


@socketio.on("control")
def control(data):
    room = data.get("room")

    if not room or room not in rooms:
        print(f"[WARN] Control event for invalid room: {room}")
        return  # ❌ Ignore instead of crashing

    r = rooms[room]
    now = time.time()

    if data["action"] == "play":
        r["playing"] = True
        r["last_update"] = now

    elif data["action"] == "pause":
        if r["playing"]:
            r["time"] += now - r["last_update"]
        r["playing"] = False

    elif data["action"] == "seek":
        r["time"] = data.get("time", 0)
        r["last_update"] = now

    emit("sync", r, room=room)


if __name__ == "__main__":
    socketio.run(app, debug=True)
